//
//  ViewController.swift
//  XMLParsesDemo
//
//  Created by Carl on 2022/11/4.
// https://www.jianshu.com/p/4311627f9c37


import UIKit

class ViewController: UIViewController {
    
    var dic0 = [String:String]()
    var dic1 = [String:String]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        getChinese()
        getEnglist()
        
        chineseKeyEnglishValue()
        // Do any additional setup after loading the view.
    }
    
    
    func getChinese(){
        //获取xml文件路径
        let file = Bundle.main.path(forResource: "strings", ofType: "xml")
        let url = URL(fileURLWithPath: file!)
        //获取xml文件内容
        let xmlData = try! Data(contentsOf: url)
         
        //构造XML文档
        let doc = try! DDXMLDocument(data: xmlData, options:0)
         
        //利用XPath来定位节点（XPath是XML语言中的定位语法，类似于数据库中的SQL功能）
        let users = try! doc.nodes(forXPath: "//resources/string") as! [DDXMLElement]
        for user in users {
            let name = user.attribute(forName: "name")!.stringValue!
            let v = user.stringValue!
            dic0[name] = v
        }
        
        
    }
    
    func getEnglist(){
        //获取xml文件路径
        let file = Bundle.main.path(forResource: "strings(1)", ofType: "xml")
        let url = URL(fileURLWithPath: file!)
        //获取xml文件内容
        let xmlData = try! Data(contentsOf: url)
         
        //构造XML文档
        let doc = try! DDXMLDocument(data: xmlData, options:0)
         
        //利用XPath来定位节点（XPath是XML语言中的定位语法，类似于数据库中的SQL功能）
        let users = try! doc.nodes(forXPath: "//resources/string") as! [DDXMLElement]
        for user in users {
            let name = user.attribute(forName: "name")!.stringValue!
            let v = user.stringValue!
            dic1[name] = v
        }
    }
    
    func chineseKeyEnglishValue(){
        self.dic0.forEach { key,value in
            let str = String(format: "\"%@\" = \"%@\";\n", value,value)
            print(str)
        }
        
        self.dic1.forEach { key,value in
            if let chinese = dic0[key] {
                let str = String(format: "\"%@\" = \"%@\";\n", chinese,value)
                print(str)
            }
         
        }
    }
    

    
    func testXML() {
            //获取xml文件路径
            let file = Bundle.main.path(forResource: "users", ofType: "xml")
            let url = URL(fileURLWithPath: file!)
            //获取xml文件内容
            let xmlData = try! Data(contentsOf: url)
             
            //构造XML文档
            let doc = try! DDXMLDocument(data: xmlData, options:0)
             
            //利用XPath来定位节点（XPath是XML语言中的定位语法，类似于数据库中的SQL功能）
            let users = try! doc.nodes(forXPath: "//User") as! [DDXMLElement]
            for user in users {
                let uid = user.attribute(forName: "id")!.stringValue
                //DDXMLElementAdditions提供了elementForName获取单个节点，不用获取数组了
                let uname = user.forName("name")!.stringValue
                //获取tel节点的子节点
                let telElement = user.forName("tel")! as DDXMLElement
                let mobile = (telElement.forName("mobile")! as DDXMLElement).stringValue
                let home = (telElement.forName("home")! as DDXMLElement).stringValue
                print("User: uid:\(uid!),uname:\(uname!),mobile:\(mobile!),home:\(home!)")
            }
        }

}

